##############################################################################
# Subject: ICS 3UI
# Teacher: Mr. Schattman
# Assignment: Team Coding Assignment: Factoring Project
# Purpose: A toolbox of functions for factoring trinomials and binomials
# Authors: Harry Kim, Matthews Ma
# Date: April 29, 2019
##############################################################################

from math import *
from fractions import *


def getABCvalues(trinomial):
    """Separates the ABC values from a trinomial or binomial."""
    # trinomial: ["ax**2 + bx + c"]

    trinomialArray = trinomial.split("x**2")  # trinomialArray: ["a", "+ bx + c"]

    if trinomial.count("x") == 2:
        # A trinomial or binomial with b term

        subArray = trinomialArray[1].split("x")  # subArray: ["+ b", "+ c"]

        del trinomialArray[1] # Destroy subArray from trinomialArray to make way for b and/or c

        if subArray[1] == "":
            # The c term is nonexistent, therefore, it is a binomial with a b term
            
            subArray = subArray[0]  # subArray: ["+ b"]
            subArray = subArray.replace(" ", "")    # Remove spaces

            trinomialArray.append(int(subArray))
            trinomialArray.append(0)
        else:
            # It is a trinomial

            subArray[0] = subArray[0].replace(" ", "")
            subArray[1] = subArray[1].replace(" ", "")

            trinomialArray.append(int(subArray[0]))
            trinomialArray.append(int(subArray[1]))
    else:
        # The b term is nonexistent, therefore, it is a binomial with a c term
        
        subArray = trinomialArray[1]  # subArray: ["+ c"]
        subArray = subArray.replace(" ", "")
        del trinomialArray[1]   # Destroy subArray from trinomialArray to make way for b and/or c
        
        trinomialArray.append(0)
        trinomialArray.append(int(subArray))

    if trinomialArray[0] == "":
        # If a is 1
        
        trinomialArray[0] = 1
    else:
        # Add the a value as an integer
        
        trinomialArray[0] = int(trinomialArray[0])

    return trinomialArray


def getCommonFactor(a, b, c):
    """Finds the greatest common divisor of three numbers."""
    
    return gcd(gcd(a, b), c)


def getFactorPairs(n):
    # Finds pairs of numbers that multiply to n

    root = sqrt(abs(n))  # The maximum the smaller factor can get is sqrt(n)

    # List comprehension to find factor pairs as long as they are both integers
    factorPairsPositive = [[i, n // i] for i in range(1, ceil(root) + 1) if n % i == 0]
    factorPairsNegative = [[i, n // i] for i in range(-floor(root) - 1, 0) if n % i == 0]

    factorPairs = factorPairsPositive + factorPairsNegative

    return factorPairs


def getMatchingPair(factorPairsA, factorPairsC, b):
    """Finds the factor pairs from a and c that sum to b."""

    for pairA in factorPairsA:
        for pairC in factorPairsC:
            if pairA[0] * pairC[1] + pairA[1] * pairC[0] == b:
                # Cross multiplying method for tricky trinomials
                
                return [pairA, pairC]

    return False  # If there is no matching pair


def formatSign(n):
    """Formats a number with plus and minus signs."""
    
    if n > 0:
        # For a positive number, add the plus sign

        sign = '+'
    elif n < 0:
        # For a negative number, add the negative sign and remove the original from n
        
        sign = '-'
        n = abs(n)
    else:
        sign = ""

    return sign + str(n)


def factorTrinomial(a, b, c):
    """Factors trinomials or binomials given a, b, c values."""

    # Common Factoring
    divisor = getCommonFactor(a, b, c)

    divisor = abs(divisor)

    a = int(a / divisor)
    b = int(b / divisor)
    c = int(c / divisor)

    if c == 0:
        # If it is a binomial with a b term
        
        if a < 0:
            # Factor the negative out of a
            
            divisor = divisor * -1
            a = a * -1
            b = b * -1

        # If the coefficient is 1, change it to nothing
        if divisor == 1:
            divisor = ""
        elif divisor == -1:
            divisor = "-"
        
        if a == 1:
            a = ""
        elif a == -1:
            a = "-"

        b = formatSign(b)

        return str(divisor) + "x" +"(" + str(a) + "x" + str(b) + ")"

    # Find the matching factor pairs
    factorPairsA = getFactorPairs(a)
    factorPairsC = getFactorPairs(c)

    matchingPair = getMatchingPair(factorPairsA, factorPairsC, b)  # matchingPair: [[x1, x2], [c1, c2]]

    if not matchingPair:
        if divisor == 1:
            # The trinomial cannot be factored at all

            return "Cannot be factored"
        else:
            # The trinomial can only be common factored

            a = formatSign(a)
            b = formatSign(b)
            c = formatSign(c)

            # Handles a = 1
            if a == "+1":
                a = ""
            elif a == "-1":
                a = "-"

            return str(divisor) + "(" + a + "x**2" + b + "x" + c + ")"

    # Format the factored form (x1X + c1)(x2X + c2)
    x1 = matchingPair[0][0]
    x2 = matchingPair[0][1]
    c1 = matchingPair[1][0]
    c2 = matchingPair[1][1]

    # Add + and - signs to the numbers
    c1 = formatSign(c1)

    c2 = formatSign(c2)

    # Sets the coefficients to nothing if x is 1
    if x1 == 1:
        x1 = ""

    if x2 == 1:
        x2 = ""
    
    # If a number is common factored out, add it to the equation, otherwise, add nothing
    if divisor == 1:
        divisor = ""
    else:
        divisor = str(divisor)
    

    # The final factored form of the trinomial
    expression = divisor + "(" + str(x1) + 'x' + c1 + ")" + "(" + str(x2) + 'x' + c2 + ")"

    return expression


def factor(trinomial):
    """Factors a trinomial in text form."""
    
    values = getABCvalues(trinomial)

    a = values[0]
    b = values[1]
    c = values[2]

    return factorTrinomial(a, b, c)
