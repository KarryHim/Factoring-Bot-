from FactoringToolbox import *

f = open("cases.txt", "r")

for line in f:
    line = line.rstrip()
    factored = factor(line)
    print(line.ljust(20) + "|" + "     " + factored)
    
